"""
Kingnstar: A Git-like Version Control System
"""

__version__ = "0.1.0"
__author__ = "Kingnstar Team"

from kingnstar.repo import Repository

__all__ = ["Repository"]
