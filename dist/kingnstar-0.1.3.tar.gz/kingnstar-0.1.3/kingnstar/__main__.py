"""
Allow kingnstar to be executed as a module with: python -m kingnstar
"""
from kingnstar.cli import main

if __name__ == "__main__":
    main()
